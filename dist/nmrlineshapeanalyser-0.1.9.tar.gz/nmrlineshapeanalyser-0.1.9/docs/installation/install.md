#Installation

If you have Python and pip installed, you can install nmrlineshapeanalyser with the command below:

```bash

pip install nmrlineshapeanalyser

```

All dependencies in [pyproject.toml](../../pyproject.toml) file are automatically installed

To verify that the package has been installed, run the command below in a Python console


```bash
import nmrlineshapeanalyser

```